
from spacy import load
from DepMatcher import DepMatcher
from Utils import load_rules
import pandas as pd
from Nlg import *
from nltk.tokenize import word_tokenize
from nltk.stem.porter import *
from TextToSpeech import *
from SpeechToText import *
import math
from pytimedinput import timedInput


class DialogManager:

    def __init__(self):
        self.Nlg = Nlg()
        self.TextToSpeech = TextToSpeech()
        self.SpeechToText = SpeechToText()
        # Initialize Dependency matcher with rules
        self.dep_matcher = DepMatcher()
        # Initialize dict of actual potions and ingredients
        self.actual_frame = {}
        self.wrong_word = [
            "first",
            "second",
            "third",
            "fourth",
            "fith",
            "sixth",
            "ingredient",
            "I"]
        self.check_ingredient_presence = False
        self.total_try_potion = 0
        self.ingredient_quantity = {}
        self.check_negation = False
        self.max_score = 30
        self.response = None
        self.penalty = 0
        self.total_score = 0
        self.actual_score = 0
        self.position_ingredient = None
        self.idx_potion = 0
        self.question = 0
        self.backup_question = 0
        self.check_partial_ingredient = False
        self.skip_question = False
        self.question_missing_ingredient = False
        self.question_tricky_question = False
        self.future_penalty = 0
        self.backup_answer = None
        self.timeout = False
        ##if user responde "first" check the first elem in array of ingridient in q3
        self.array_q3 = []

        # Initialize User responses frame
        self.response_frame = {}




        # load potions and ingredients dataframe
        df_potions = pd.read_json("Data/potions.json")
        # select random potion
        df_potions = df_potions.sample(n=3)
        # preprocessing phase -> cleanup dataframe and create response frame
        # and actual frame with the selected potion
        for item in df_potions[0].index.to_list():
            tmp_dict = df_potions.loc[item].to_dict()
            for i in range(0, len(
                    list(df_potions.loc[df_potions.index[0]].to_dict().values()))):
                if tmp_dict[i] == "" or math.isnan(float()):
                    del tmp_dict[i]
                if isinstance(tmp_dict[i], float) and math.isnan(tmp_dict[i]):
                    del tmp_dict[i]
            self.actual_frame[item] = tmp_dict

        myL = list(self.actual_frame.keys())
        frame_q1 = {}
        #case q2 and q3
        empty_frame = {0: None}
        self.response_frame[myL[1]] = empty_frame
        self.response_frame[myL[2]] = empty_frame
        for ingredient in self.actual_frame[myL[0]]:
            frame_q1[ingredient] = None
        self.response_frame[myL[0]] = frame_q1
        # Construct responses dict

        # Initialize current Potion
        self.current_potion = list(self.actual_frame.keys())[self.idx_potion]
        if self.idx_potion == 0:   
            self.total_try_potion = len(self.actual_frame[self.current_potion])
        else:
            self.total_try_potion = 2

        self.check_penalty = False
        # TODO : normalize score
        for i in self.response_frame.keys():
            self.total_score = self.total_score + len(self.response_frame[i])

        self.actual_score = self.total_score

    # check if the potion is complete
    def check_potion_complete(self, response_frame):
        if None in list(response_frame.values()):
            return False
        else:
            return True

    # Check if response ingredient in actual_frame == response_frame

    def check_ingredient_name(self, ingredient):

        for item in range(0, len(self.actual_frame[self.current_potion])):
            if str(self.actual_frame[self.current_potion]
                   [item]).lower() == str(ingredient.lower()):
                return item
        return None

    def get_final_score(self):
        if ((self.actual_score - self.penalty) *
                self.max_score) / self.total_score < 0:
            return 0
        else:
            return ((self.actual_score - self.penalty)
                    * self.max_score) / self.total_score

    def next_question(self):
        # end of question
        if self.idx_potion == len(self.actual_frame) - 1:
                print(f"penalty : {self.penalty}")
                final_score = self.get_final_score()
                self.TextToSpeech.getResponse(
                    self.Nlg.grade_comment(
                        ((self.actual_score -
                        self.penalty) *
                        self.max_score) /
                        self.total_score))
                if final_score >=18:
                     self.TextToSpeech.getResponse(
                        f"your final score is {final_score} over 30")

                return False
        else:
            self.backup_question = 0
            self.idx_potion += 1
            self.current_potion = list(self.actual_frame.keys())[
                self.idx_potion]
            self.question_tricky_question = False
            # update total_try_potion new potion
            self.total_try_potion = 2
            return True

    def increase_penalty(self, future_penalty):
        # case domanda 2 e 3 frame have only one element
        if len(self.response_frame[self.current_potion]) <= 1:
            # if not the first time the user receive a penalty, then I * 2 
            # otherwise I just initialize it
            if self.check_penalty:
                self.penalty = self.penalty * 2
            else:

                self.penalty = self.penalty + 0.5
                self.check_penalty = True
        else:
           
            # case 1 -> first question and I already responded one time (tricky_question)
            # case 2 -> skip the question
            # case 3 -> timeout
            if self.idx_potion == 0 and self.question_tricky_question or self.skip_question or self.timeout:
                None_elem_rFrame = len(list(filter(lambda a: None is a, list(
                    self.response_frame[self.current_potion].values()))))

                # count the penalty in base of None element in the frame
                if float(self.penalty) == 0:
                    self.penalty = 0.4
                    if None_elem_rFrame > 1:
                        if self.question_tricky_question or self.timeout or self.skip_question:
                            self.penalty = self.penalty * None_elem_rFrame
                    else:
                        self.penalty = self.penalty * 0.4

                else:
                    if None_elem_rFrame > 1:
                        self.penalty = self.penalty * None_elem_rFrame
                    else:
                        self.penalty = self.penalty * 0.4

                self.skip_question = False
            else:
                # case simple penalty
                if future_penalty == 1:
                    self.penalty = self.penalty + 0.10 * 3
                else:
                    self.penalty = self.penalty + 0.10
                    self.penalty = self.penalty * 2 * future_penalty
                self.future_penalty = 0

    def backup_strategy(self):
        if self.backup_question == 1 :
            self.future_penalty = 0
            self.backup_question += 1
            self.TextToSpeech.getResponse(self.Nlg.backup_question(self.backup_answer))
            return True
        else:
            return False

    def check_backup_strategy(self, response, currentPotion):
        if str(self.current_potion) == str(currentPotion) and self.backup_question == 0 and not any(
                list(self.response_frame[self.current_potion].values())):
            print(
                self.Nlg.get_comment("neutral"))
            self.backup_answer = response
            self.backup_question = 1

            return True

        else:
            if self.backup_question > 0:
                self.increase_penalty(
                    self.future_penalty)
                self.TextToSpeech.getResponse(self.Nlg.get_comment("bad_answer"))
            return False

    def input_timer(self, question):
        response = timedInput(f"{question}\n", timeout=60)
        if response[1]:
            self.timeout = True
            self.increase_penalty(0)
            print("You took too long to answer!")
            if not self.next_question():
                return False
        else:
            self.timeout = False
            return response[0]

    def generate_array_ingredient(self, ingredients, rand_ingredient):
        ingredients = list(ingredients.values())
        ingredients.append(rand_ingredient)
        random.shuffle(ingredients)
        self.array_q3 = ingredients
        ingr = ', '.join(ingredients)
        return ingr

    def check_position(self, item_to_check, rand_ingredient):
        for res in item_to_check:
            for idx in self.wrong_word[:5]:
                if str(idx).lower() in str(res):
                    if self.array_q3[self.wrong_word.index(
                            idx)] == rand_ingredient:
                        return True

        return False

    def start(self):
        self.TextToSpeech.getResponse(self.Nlg.greetings())
        exit = True
        while exit:
            check_score = self.get_final_score()
            if check_score == 0:
                return self.TextToSpeech.getResponse(self.Nlg.grade_comment(check_score))
            if self.total_try_potion <= 0:
                if not self.next_question():
                    break

            else:
                # DOMANDA 1 response = None
                if self.idx_potion == 0:
                    self.question = 0
                    if self.backup_strategy():
                        self.TextToSpeech.getResponse(
                            self.Nlg.ask_ingredients(self.current_potion))
                    else:
                        if self.question_missing_ingredient:
                            self.question_missing_ingredient = False
                            self.TextToSpeech.getResponse(
                                self.Nlg.missing_ingredients())
                        else:
                            if self.question_tricky_question:
                                self.TextToSpeech.getResponse(
                                    self.Nlg.tricky_question())

                            else:
                                self.TextToSpeech.getResponse(
                                    self.Nlg.ask_ingredients(self.current_potion))
                               
                # DOMANDA 2
                if self.idx_potion == 1:
                  
                    self.position_ingredient = random.randint(
                        0, len(self.actual_frame[self.current_potion]) - 1)
                   
                    self.question = 1
                    if self.backup_strategy():
                        self.TextToSpeech.getResponse(self.Nlg.true_false_question(self.actual_frame[str(
                            self.current_potion)][self.position_ingredient], self.current_potion))
                    else:
                        self.TextToSpeech.getResponse(self.Nlg.true_false_question(self.actual_frame[str(
                            self.current_potion)][self.position_ingredient], self.current_potion))

                # DOMANDA 3
                if self.idx_potion == len(self.actual_frame) - 1:
                    actual_frame_values = list(
                        self.actual_frame[self.current_potion].values())
                    rand_ingredient = self.actual_frame[list(self.actual_frame.keys())[self.idx_potion - 1]][random.randint(
                        0, len(self.actual_frame[list(self.actual_frame.keys())[self.idx_potion - 1]].values()) - 1)]
                    while (rand_ingredient in actual_frame_values):
                        rand_ingredient = self.actual_frame[list(self.actual_frame.keys())[self.idx_potion - 1]][random.randint(
                            0, len(self.actual_frame[list(self.actual_frame.keys())[self.idx_potion - 1]].values()) - 1)]
                    if rand_ingredient not in list(
                            self.actual_frame[self.current_potion].values()):
                        self.question = 2
                        self.backup_strategy()
                        self.TextToSpeech.getResponse(self.Nlg.find_wrong_question(
                            self.current_potion, self.generate_array_ingredient(self.actual_frame[self.current_potion], rand_ingredient)))

                response = self.SpeechToText.getSpeech(True)

                if response is None:
                    self.increase_penalty(0)
                    if not self.next_question():
                        return
                else:


                    if response.lower() == "exit":
                        break
                    else:
                        if "next question" in response.lower():
                            self.skip_question = True
                            self.increase_penalty(0)
                            if not self.next_question():
                                return
                        else:
                            if len(response) == 0:
                                self.TextToSpeech.getResponse(self.Nlg.get_comment("neutral"))
                            else:
                                self.current_potion = list(self.actual_frame.keys())[
                                    self.idx_potion]
                                match = self.dep_matcher.get_matches(response)
                                matches = []
                                print(f"match : {match}")
                                local_currentPotion = self.current_potion
                                # cleaning match list from useless output
                                if self.idx_potion != 2 or self.question != 2:
                                    for value in match:
                                        valueToRemove = [
                                            elem in value[1].lower() for elem in self.wrong_word]
                                        if not any(valueToRemove):
                                            matches.append(value)
                                else:
                                    matches = match
                                    

                                if len(matches) == 0 :
                                    if self.idx_potion == 2:
                                        if self.check_position(
                                            word_tokenize(response.lower()), rand_ingredient):
                                            print(
                                                self.Nlg.get_comment("good_answer"))
                                            if not self.next_question():
                                                return

                                    else:
                                        self.TextToSpeech.getResponse(self.Nlg.get_comment("neutral"))
                                else:
                                    # check if i finished the total try for this potion
                                        local_currentPotion = self.current_potion
                                        self.total_try_potion -= 1
                                        for item in matches:
                                            if item[0] == "yesOrNo":
                                                # DOMANDA 1 pt2
                                                if self.question_tricky_question:
                                                    # are you sure all ingredient has beeen listed ?
                                                    if str(item[1]).lower() == "yes":
                                                        if self.check_potion_complete(
                                                                self.response_frame[self.current_potion]):
                                                            print(
                                                                self.Nlg.get_comment("good_answer"))
                                                            # correct answer check if
                                                            # it's complete
                                                            if not self.next_question():
                                                                break
                                                        else:
                                                            self.increase_penalty(0)
                                                            self.TextToSpeech.getResponse(self.Nlg.get_comment(
                                                                "bad_answer"))
                                                            if not self.next_question():
                                                                break

                                                    if str(item[1]).lower() == "no" and not self.check_potion_complete(
                                                            self.response_frame[self.current_potion]):
                                                        self.question_missing_ingredient = True
                                                    if str(item[1]).lower() == "no" and self.check_potion_complete(
                                                            self.response_frame[self.current_potion]):
                                                        self.TextToSpeech.getResponse(self.Nlg.get_comment(
                                                            "bad_answer"))
                                                        self.increase_penalty(0)
                                                        if not self.next_question():
                                                            break
                                                # DOMANDA 2
                                                # in this question piton ask if the
                                                # ingredient X is present in the potion
                                                # Y
                                                elif self.question == 1:
                                                    # yes, ___ is present
                                                    # no, ___ isn't present
                                                    idx_yes_no_potion = self.check_ingredient_name(
                                                        self.actual_frame[self.current_potion][self.position_ingredient])
                                                    if str(item[1]).lower() == "yes":
                                                        if idx_yes_no_potion is not None:
                                                           
                                                            self.response_frame[self.current_potion] = "yes"
                                                            print(
                                                                self.Nlg.get_comment("good_answer"))
                                                            if not self.next_question():
                                                                return

                                                        else:
                                                            # bad_answer
                                                            self.TextToSpeech.getResponse(self.Nlg.get_comment(
                                                                "bad_answer"))
                                                            self.increase_penalty(0)

                                                    elif str(item[1]).lower() == "no":
                                                        if idx_yes_no_potion is not None:
                                                            self.TextToSpeech.getResponse(self.Nlg.get_comment(
                                                                "bad_answer"))

                                                            # match in ingrediente ->
                                                            # wrong answer
                                                            self.increase_penalty(0)
                                                        else:
                                                            # match in ingrediente ->
                                                            # right answer
                                                            self.TextToSpeech.getResponse(self.Nlg.get_comment(
                                                                "good_answer"))
                                                            self.response_frame[self.current_potion] = "no"
                                                            if not self.next_question():
                                                                return



                                            # DOMANDA 3
                                            # is this question you need to indicate the
                                            # wrong ingredient
                                            if self.question == 2:
                                                if str(rand_ingredient).lower() == str(
                                                        item[1]).lower():
                                                    self.TextToSpeech.getResponse(self.Nlg.get_comment(
                                                        "good_answer"))

                                                    self.response_frame[self.current_potion] = "right"
                                                    if not self.next_question():
                                                        return
                                               
                                                else:
                                                    if self.check_position(
                                                        word_tokenize(response.lower()), rand_ingredient):
                                                        print(
                                                            self.Nlg.get_comment("good_answer"))
                                                        if not self.next_question():
                                                            return

                                            if item[0] == "Is_ingredient" and self.question == 0:
                                                idx = self.check_ingredient_name(
                                                    item[1])
                                                # se idx != None -> match
                                                if idx is not None:
                                                    # check if neg right ingredient
                                                    if not self.check_negation:
                                                        if self.response_frame[self.current_potion][idx] is None:
                                                            # add ingredient in frame
                                                            # -> good_answer
                                                            self.response_frame[self.current_potion][idx] = item[1]

                                                        else:
                                                            # ingredient already in the
                                                            # frame -> neutral comment
                                                            self.TextToSpeech.getResponse(self.Nlg.get_comment(
                                                                "neutral"))
                                                    else:
                                                        self.future_penalty += 1
                                                        self.check_negation = not self.check_negation
                                                else:
                                                    # check if match is part of other
                                                    # match and check if the other
                                                    # match is an ingredient
                                                    myMatches = [elem[1]
                                                                for elem in matches]
                                                    if any([item[1] in myMatches[elem] for elem in range(
                                                            0, myMatches.index(item[1]))]):
                                                        listMatches = list(filter(lambda a: item[1] in a, myMatches))
                                                        if len(listMatches) > 0:
                                                            pass

                                                    else:
                                                        self.future_penalty += 1
                                                    
                                            if item[0] == "Is_not_ingredient":
                                                # we'll check if the negated match is
                                                # an ingredient
                                                self.check_negation = True

                                       
                                        if self.idx_potion == 0:
                                            if self.check_potion_complete(
                                                    self.response_frame[self.current_potion]):
                                                print(
                                                    self.Nlg.get_comment("good_answer"))
                                                if self.question_tricky_question:
                                                    if not self.next_question():
                                                        break
                                                else:
                                                    self.question_tricky_question = True

                                            else:
                                                self.question_tricky_question = True

                                        # check if the response is completly wrong and
                                        # it is the first time
                                        self.check_backup_strategy(
                                            response.lower(), local_currentPotion)
                                        if self.idx_potion == 0 and self.backup_question > 1:
                                            # print("-----------SET TRICKY QUESTION------")
                                            self.question_tricky_question = True

        return print("exit")


if __name__ == "__main__":
    d = DialogManager()
    d.start()
